FooCoin (FOO)

Blah, blah, blah.